# LUXORA — Cinematic Real Estate Demo

A cinematic, responsive real-estate concept built with React, TypeScript, Three.js, React Three Fiber, GSAP and ScrollTrigger.

## Motion references incorporated
- Minimal WebGL-style loading screen with progress indicator and orbit animation
- Light/ink-style hero wipe transition revealing the architecture image and typography
- Cinematic background parallax tied to page scroll
- GSAP text entrances and section scroll reveals
- Property photography clip-path reveals and a subtle light sweep on hover
- Floating gold orbital details, interactive 3D globe and clickable location markers
- Responsive menu, expandable FAQ and WhatsApp enquiry handoff

## Run locally
```bash
npm install
npm run dev
```
Open the local URL printed by Vite.

## Production build
```bash
npm run build
```
Netlify settings:
- Build command: `npm run build`
- Publish directory: `dist`

## Before using for a real client
- Replace LUXORA brand with the client's approved identity.
- Replace illustrative project names, locations, prices and details with verified information.
- Replace demo images with client-owned or appropriately licensed photography.
- Set the real WhatsApp destination in `src/App.tsx`. Current enquiry flow opens WhatsApp without a preset recipient and does not save data to a server.
- Test on target mobile devices and run `npm run build` before launch.
- This is a high-fidelity starter demo, not a fully production-audited 3D property platform. Production work should include performance checks, asset licensing, accessibility review and final browser/device testing.
